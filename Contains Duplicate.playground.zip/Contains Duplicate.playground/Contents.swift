import Foundation

func containsDuplicate(_ nums: [Int]) -> Bool {
    var dict: [Int: Int] = [:]
    for num in nums {
        if let _ = dict[num] {
            return true
        } else {
            dict[num] = 1
        }
    }
    return false
}

func containsDuplicate1(_ nums: [Int]) -> Bool {
    return nums.count > Set(nums).count
}
