import Foundation

func majorityElement(_ nums: [Int]) -> [Int] {
    var result: [Int] = []
    var dict: [Int: Int] = [:]
    
    for num in nums {
        if let value = dict[num] {
            dict[num] = value + 1
        } else {
            dict[num] = 1
        }
    }
    
    for (key, value) in dict {
        if value > nums.count / 3 {
            result.append(key)
        }
    }
    
    return result
}
