import Foundation

func shortestWordDistance(_ words: [String], _ word1: String, _ word2: String) -> Int {
    var w1 = -1
    var w2 = -1
    var distance = words.count - 1
    
    if word1 == word2 {
        for i in 0...words.count - 1 {
            if words[i] == word1 {
                if w1 != -1 {
                    distance = min(distance, abs(i - w1))
                    w1 = i
                } else {
                    w1 = i
                }
            }
        }
    } else {
        for i in 0...words.count - 1 {
            if words[i] == word1 {
                w1 = i
            } else if words[i] == word2 {
                w2 = i
            }
            
            if w1 != -1 && w2 != -1 {
                distance = min(distance, abs(w2 - w1))
            }
        }
    }
    return distance
}

shortestWordDistance(["practice", "makes", "perfect", "coding", "makes", "makes"], "makes", "coding")
//["practice", "makes", "perfect", "coding", "makes", ",makes"]
//word1 = “makes”, word2 = “coding”
// word1 = "makes", word2 = "makes"
