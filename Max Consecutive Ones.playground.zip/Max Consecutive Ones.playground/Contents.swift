import Foundation

func findMaxConsecutiveArOnes(_ nums: [Int]) -> Int {
    var globalMax: Int = 0
    var localMax: Int = 0
    for num in nums {
        if num == 1 {
            localMax += 1
        } else {
            globalMax = max(globalMax, localMax)
            localMax = 0
        }
    }
    
    return max(globalMax, localMax)
}

// https://leetcode.com/problems/max-consecutive-ones/
