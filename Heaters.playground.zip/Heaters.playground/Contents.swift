import Foundation

func findRadius(_ houses: [Int], _ heaters: [Int]) -> Int {
    var radius: Int = 0
    let heaters: [Int] = heaters.sorted()
    
    for house in houses {
        let minDistance = abs(findMinDistance(house: house, heaters: heaters))
        radius = max(minDistance, radius)
    }
    
    return radius
}

func findMinDistance(house: Int, heaters: [Int]) -> Int {
    var low: Int = 0
    var hight: Int = heaters.count - 1
    while low < hight {
        let mid: Int = low + (hight - low) / 2
        if house > heaters[mid] {
            low = mid + 1
        } else {
           hight = mid
        }
    }
    
    if low > 0 {
        return heaters[low] - house > house - heaters[low - 1] ? house - heaters[low - 1] : heaters[low] - house
    } else {
        return heaters[low] - house
    }
}
