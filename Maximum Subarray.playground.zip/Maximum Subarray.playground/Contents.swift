import Foundation

func maxSubArray(_ nums: [Int]) -> Int {
    guard nums.count > 1 else { return nums[0] }
    
    var result = nums[0]
    var sum = nums[0]
    
    for i in 1...nums.count - 1 {
        sum = max(nums[i], sum + nums[i])
        result = max(result, sum)
    }
    return result
}
//[-2,1,-3,4,-1,2,1,-5,4],

maxSubArray([-2,1,-3,4,-1,2,1,-5,4])
