import Foundation

func twoSum(_ nums: [Int], _ target: Int) -> [Int] {
    let arr = nums.sorted()
    var left = 0
    var right = arr.count - 1
    var result = [Int]()
    
    while left < right {
        if arr[left] + arr[right] > target {
            right -= 1
        } else if arr[left] + arr[right] < target {
            left += 1
        } else {
            break
        }
    }
    
    for i in 0...nums.count - 1 {
        if nums[i] == arr[left] || nums[i] == arr[right] {
            result.append(i)
        }
    }
    return result
}

func twoSum2(_ nums: [Int], _ target: Int) -> [Int] {
    var dict = [Int: Int]()
    
    for (index, num) in nums.enumerated() {
        if let lastIndex = dict[target - num] {
            return [lastIndex, index]
        } else {
            dict[num] = index
        }
    }
    return []
}
