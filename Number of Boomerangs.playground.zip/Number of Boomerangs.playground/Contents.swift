import Foundation

func distanceBetweenPoints(pointA: [Int], pointB: [Int]) -> Int {
    return (pointA[0] - pointB[0])*(pointA[0] - pointB[0]) + (pointA[1] - pointB[1])*(pointA[1] - pointB[1])
}

func numberOfBoomeranges(_ points: [[Int]]) -> Int {
    var result: Int = 0
    var dict: [Int: Int] = [:]
    
    for i in 0...points.count - 1 {
        for j in 0...points.count - 1 {
            let distance = distanceBetweenPoints(pointA: points[i], pointB: points[j])
            if let dis = dict[distance] {
                dict[distance] = dis + 1
            } else {
                dict[distance] = 1
            }
        }
        for (_, value) in dict {
            if value > 1 {
                result += value * (value - 1)
            }
        }
        dict = [:]
    }
    return result
}
