import Foundation

func rotate(_ matrix: inout [[Int]]) {
    let count = matrix.count
    for i in 0..<matrix.count / 2 {
        let start = i, end = matrix.count - 1 - i
        for j in start..<end {
            (matrix[i][j], matrix[j][count - 1 - i], matrix[count - 1 - i][count - 1 - j], matrix[count - 1 - j][i]) = (matrix[count - 1 - j][i], matrix[i][j], matrix[j][count - 1 - i], matrix[count - 1 - i][count - 1 - j])
        }
    }
}
