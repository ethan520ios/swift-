import Foundation

func threeSumClosest(_ nums: [Int], _ target: Int) -> Int {
    let numsArr = nums.sorted()
    var diff = 0
    for i in 0...numsArr.count - 3 {
        var left = i + 1
        var right = numsArr.count - 1
        let sum = target - numsArr[i]
        while left < right {
            if numsArr[left] + numsArr[right] < sum {
                left += 1
            } else if numsArr[left] + numsArr[right] > sum {
                right -= 1
            }
        }
    }
}

//[[1,2,4,8,16,32,64,128] 82
