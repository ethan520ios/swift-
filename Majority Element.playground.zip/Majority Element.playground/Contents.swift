import Foundation

func majorityElement(_ nums: [Int]) -> Int {
    var dict: [Int: Int] = [:]
    for num in nums {
        if let value = dict[num] {
            dict[num] = value + 1
            if value + 1 > nums.count / 2 {
                return num
            }
        } else {
            dict[num] = 1
        }
    }
    return nums[0]
}
