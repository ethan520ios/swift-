import Foundation

func moveZeros(_ nums: inout [Int]) {
    var i: Int = 0
    var numberOfZeros: Int = 0
    while i < nums.count {
        if nums[i] == 0 {
            nums.remove(at: i)
            numberOfZeros += 1
        } else {
            i += 1
        }
    }
    nums.append(contentsOf: Array(repeating: 0, count: numberOfZeros))
}


func moveZeros2(_ nums: inout [Int]) {
    var idx: Int = 0
    
    for i in 0...nums.count - 1 {
        if nums[i] != 0 {
            nums[idx] = nums[i]
            idx += 1
        }
    }
    
    while idx < nums.count {
        nums[idx] = 0
        idx += 1
    }
}

func moveZeros3(_ nums: inout [Int]) {
    var j: Int = 0
    
    for i in 0...nums.count - 1 {
        if nums[i] != 0 {
            (nums[i], nums[j]) = (nums[j], nums[i])
            j += 1
        }
    }
}
