import Foundation

func islandPerimeter(_ grid: [[Int]]) -> Int {
    var perimeter: Int = 0
    var dict: [[Int: Int]: Bool] = [:]
    
    for i in 0...grid.count - 1 {
        for j in 0...grid[0].count - 1 {
            if grid[i][j] == 1 {
                perimeter += 4
                dict[[i: j]] = true
                if let _ = dict[[i - 1: j]] {
                    perimeter -= 2
                }
                if let _ = dict[[i: j - 1]] {
                    perimeter -= 2
                }
            }
        }
    }
    return perimeter
}

func islandPerimeter(_ grid: [[Int]]) -> Int {
    var island: Int = 0
    var neighbor: Int = 0
    
    for i in 0...grid.count - 1 {
        for j in 0...grid[0].count - 1 {
            if grid[i][j] == 1 {
                island += 1
                if i < grid.count - 1 && grid[i + 1][j] == 1 {
                    neighbor += 1
                }
                if j < grid[0].count - 1 && grid[i][j + 1] == 1 {
                    neighbor += 1
                }
            }
        }
    }
    return island * 4 - neighbor * 2
}
