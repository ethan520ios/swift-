import Foundation

func intersect(_ nums1: [Int], _ nums2: [Int]) -> [Int] {
    guard nums1.count > 0, nums2.count > 0 else { return [] }
    let arr1 = nums1
    var arr2 = nums2
    var result: [Int] = []
    
    for i in 0...arr1.count - 1 {
        if arr2.count == 0 {
            break
        }
        for j in 0...arr2.count - 1 {
            if arr1[i] == arr2[j] {
                result.append(arr2[j])
                arr2.remove(at: j)
                break
            }
        }
    }
    return result
}

func intersect1(_ nums1: [Int], _ nums2: [Int]) -> [Int] {
    var result: [Int] = []
    let arr1 = nums1.sorted()
    let arr2 = nums2.sorted()
    
    var i = 0
    var j = 0
    
    while i < arr1.count && j < arr2.count {
        if arr1[i] > arr2[j] {
            j += 1
        } else if arr1[i] < arr2[j] {
            i += 1
        } else {
            result.append(arr1[i])
            i += 1
            j += 1
        }
    }
    return result
}
