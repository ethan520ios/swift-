import Foundation

func summaryRanges(_ nums: [Int]) -> [String] {
    guard nums.count > 0 else { return [] }
    var start = 0
    var end = start
    var range = ""
    var result = [String]()
    
    for i in 0...nums.count - 1 {
        if i != nums.count - 1 {
            if nums[i] + 1 == nums[i + 1] {
                end = i + 1
            } else {
                if start == end {
                    range = "\(nums[start])"
                } else {
                    range = "\(nums[start])->\(nums[end])"
                }
                result.append(range)
                start = i + 1
                end = start
            }
        } else {
            if start == end {
                range = "\(nums[start])"
            } else {
                range = "\(nums[start])->\(nums[end])"
            }
            result.append(range)
        }
    }
    
    return result
}
