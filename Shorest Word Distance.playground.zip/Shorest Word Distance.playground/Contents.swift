import Foundation

func shortestDistance(_ words: [String], _ word1: String, _ word2: String) -> Int {
    var w1 = -1
    var w2 = -1
    var distance = words.count
    
    for i in 0...words.count - 1 {
        if words[i] == word1 {
            w1 = i
        } else if words[i] == word2 {
            w2 = i
        }
        if w1 != -1 && w2 != -1 {
            distance = min(distance, abs(w2 - w1))
        }
    }
    return distance
}
