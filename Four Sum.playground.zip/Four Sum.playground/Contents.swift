import Foundation

func fourSum(_ nums: [Int], _ target: Int) -> [[Int]] {
    guard nums.count > 3 else { return [] }
    
    let sortedNums = nums.sorted()
    var threeSum = 0
    var twoSum = 0
    var left: Int
    var right: Int
    var result = [[Int]]()
    
    for i in 0...sortedNums.count - 4 {
        threeSum = target - sortedNums[i]
        for j in i + 1...sortedNums.count - 3 {
            twoSum = threeSum - sortedNums[j]
            left = j + 1
            right = nums.count - 1
            
            while left < right {
                if sortedNums[left] + sortedNums[right] < twoSum {
                    left += 1
                } else if sortedNums[left] + sortedNums[right] > twoSum {
                    right -= 1
                } else {
                    result.append([sortedNums[i], sortedNums[j], sortedNums[left], sortedNums[right]])
                    left += 1
                    right -= 1
                }
            }
        }
    }
    return Array(Set(result))
}
