import Foundation

func threeSum(_ nums: [Int]) -> [[Int]] {
    guard nums.count > 2 else { return [] }
    
    let numsArr = nums.sorted()
    var result = [[Int]]()
    
    for i in 0...numsArr.count - 3 {
        var left = i + 1
        var right = numsArr.count - 1
        
        while left < right {
            if numsArr[left] + numsArr[right] < -numsArr[i] {
                left += 1
            } else if numsArr[left] + numsArr[right] > -numsArr[i] {
                right -= 1
            } else {
                result.append([numsArr[i], numsArr[left], numsArr[right]])
                left += 1
            }
        }
    }
    return Array(Set(result))
}
