import Foundation

func removeElement(_ nums: inout [Int], _ val: Int) -> Int {
    var index: Int = 0
    while index < nums.count {
        if nums[index] == val {
            nums.remove(at: index)
        } else {
            index += 1
        }
    }
    
    return nums.count
}

func removeElement2(_ nums: inout [Int], _ val: Int) -> Int {
    nums = nums.filter { $0 != val }
    return nums.count
}
